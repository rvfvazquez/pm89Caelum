﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CaelumEstoque.Models
{
    public class Usuario
    {
        public String Login { get; set; }

        public String Senha { get; set; }
    }
}